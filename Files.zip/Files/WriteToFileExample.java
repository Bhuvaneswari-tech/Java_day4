package Files;

import java.io.FileWriter;
import java.io.IOException;

public class WriteToFileExample {

	public static void main(String[] args) {
		try {
			FileWriter write1 = new FileWriter("output1.txt");
			write1.write("Hello, this is my first file write in Java");
			write1.close();
			System.out.println("Successfuly written to file.");
		}
		catch(IOException e) {
			System.out.println("An error occured.");
			e.printStackTrace();
		}

	}

}
