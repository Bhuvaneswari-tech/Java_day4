package SolidPrinciples;

public class PaymentProcessor {
//	public void processPayment(String paymentType) {
//        if (paymentType.equals("CREDITCARD")) {
//            System.out.println("Processing credit card payment");
//        } else if (paymentType.equals("UPI")) {
//            System.out.println("Processing UPI payment");
//        } else if (paymentType.equals("PAYPAL")) {
//            System.out.println("Processing PayPal payment");
//        }
//    }
	
	public void process(Payment payment) {
        payment.pay();
    }
}
