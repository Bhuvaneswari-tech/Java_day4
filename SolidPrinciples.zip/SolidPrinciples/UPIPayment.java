package SolidPrinciples;

public class UPIPayment implements Payment{

	@Override
	public void pay() {
		System.out.println("Processing UPI payment.");
		
	}
}
