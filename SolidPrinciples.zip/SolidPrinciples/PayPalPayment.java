package SolidPrinciples;

public class PayPalPayment implements Payment{

	@Override
	public void pay() {
		System.out.println("Processing PayPal Payment");
		
	}

}
