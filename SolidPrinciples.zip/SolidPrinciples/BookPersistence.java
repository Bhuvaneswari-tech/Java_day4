package SolidPrinciples;

import java.io.FileWriter;
import java.io.IOException;

public class BookPersistence {
	public void saveToFile(Book1 book, String filename) throws IOException {
        FileWriter writer = new FileWriter(filename);
        writer.write(book.getDetails());
        writer.close();
    }
}
