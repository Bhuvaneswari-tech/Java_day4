package SolidPrinciples;

public class CreditCardPayment implements Payment{

	@Override
	public void pay() {
		System.out.println("Processing Credit card Payment.");
		
	}

}
