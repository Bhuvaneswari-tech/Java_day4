package SolidPrinciples;

import java.io.FileWriter;
import java.io.IOException;

public class Book {
	private String title;
    private String author;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
    }

    public void saveToFile(String filename) throws IOException {
        FileWriter writer = new FileWriter(filename);
        writer.write("Title: " + title + "\nAuthor: " + author);
        writer.close();
    }

    public void printBook() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
    }
}


//Multiple functionality is here
//Not satisfying SRP
//Constructor - intilization, File Creation and writing, Output display