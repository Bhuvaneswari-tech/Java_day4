package SolidPrinciples;

public class BookPrinter {
	public void print(Book1 book) {
        System.out.println(book.getDetails());
    }
}
