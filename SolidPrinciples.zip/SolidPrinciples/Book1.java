package SolidPrinciples;

public class Book1 {
	private String title;
    private String author;

    public Book1(String title, String author) {
        this.title = title;
        this.author = author;
    }

    public String getDetails() {
        return "Title: " + title + "\nAuthor: " + author;
    }
}
