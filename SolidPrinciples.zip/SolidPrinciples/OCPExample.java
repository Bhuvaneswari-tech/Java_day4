package SolidPrinciples;

public class OCPExample {

	public static void main(String[] args) {
		PaymentProcessor processor = new PaymentProcessor();
		
		Payment credit = new CreditCardPayment();
		Payment upi = new UPIPayment();
		Payment paypal = new PayPalPayment();
		
		processor.process(credit);
		processor.process(upi);
		processor.process(paypal);

	}

}
