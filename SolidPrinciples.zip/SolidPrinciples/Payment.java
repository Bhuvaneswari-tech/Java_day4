package SolidPrinciples;

public interface Payment {
	void pay();

}
