package SolidPrinciples;

import java.io.IOException;

public class SRPExample {

	public static void main(String[] args) {
		Book1 book = new Book1("Clean Code", "Robert C. Martin");

        BookPrinter printer = new BookPrinter();
        printer.print(book);

        BookPersistence persistence = new BookPersistence();
        try {
            persistence.saveToFile(book, "book.txt");
            System.out.println("Book saved to file.");
        } catch (IOException e) {
            e.printStackTrace();
        }

	}

}
